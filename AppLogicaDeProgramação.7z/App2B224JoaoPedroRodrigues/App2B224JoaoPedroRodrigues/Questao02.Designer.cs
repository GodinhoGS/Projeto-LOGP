﻿namespace App2B224JoaoPedroRodrigues
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao02));
            this.pnlCinema = new System.Windows.Forms.Panel();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblCapacidade = new System.Windows.Forms.Label();
            this.lblQntSalas = new System.Windows.Forms.Label();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCapacidade = new System.Windows.Forms.TextBox();
            this.txtQntSalas = new System.Windows.Forms.TextBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlCinema.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCinema
            // 
            this.pnlCinema.BackColor = System.Drawing.Color.Red;
            this.pnlCinema.Controls.Add(this.lblTitulo);
            this.pnlCinema.Location = new System.Drawing.Point(2, 0);
            this.pnlCinema.Margin = new System.Windows.Forms.Padding(6);
            this.pnlCinema.Name = "pnlCinema";
            this.pnlCinema.Size = new System.Drawing.Size(1179, 220);
            this.pnlCinema.TabIndex = 0;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(22, 288);
            this.lblNome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(219, 24);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Insire o nome do cinema";
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.Location = new System.Drawing.Point(22, 358);
            this.lblEndereco.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(251, 24);
            this.lblEndereco.TabIndex = 2;
            this.lblEndereco.Text = "Insira o endereço do cinema";
            // 
            // lblCapacidade
            // 
            this.lblCapacidade.AutoSize = true;
            this.lblCapacidade.Location = new System.Drawing.Point(22, 438);
            this.lblCapacidade.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCapacidade.Name = "lblCapacidade";
            this.lblCapacidade.Size = new System.Drawing.Size(304, 24);
            this.lblCapacidade.TabIndex = 3;
            this.lblCapacidade.Text = "Insira a capacidade total do cinema";
            // 
            // lblQntSalas
            // 
            this.lblQntSalas.AutoSize = true;
            this.lblQntSalas.Location = new System.Drawing.Point(22, 521);
            this.lblQntSalas.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblQntSalas.Name = "lblQntSalas";
            this.lblQntSalas.Size = new System.Drawing.Size(243, 24);
            this.lblQntSalas.TabIndex = 4;
            this.lblQntSalas.Text = "Insire a quantidade de salas";
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(350, 358);
            this.txtEndereco.Margin = new System.Windows.Forms.Padding(6);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(530, 29);
            this.txtEndereco.TabIndex = 5;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(350, 288);
            this.txtNome.Margin = new System.Windows.Forms.Padding(6);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(530, 29);
            this.txtNome.TabIndex = 6;
            // 
            // txtCapacidade
            // 
            this.txtCapacidade.Location = new System.Drawing.Point(350, 438);
            this.txtCapacidade.Margin = new System.Windows.Forms.Padding(6);
            this.txtCapacidade.Name = "txtCapacidade";
            this.txtCapacidade.Size = new System.Drawing.Size(530, 29);
            this.txtCapacidade.TabIndex = 7;
            // 
            // txtQntSalas
            // 
            this.txtQntSalas.Location = new System.Drawing.Point(350, 515);
            this.txtQntSalas.Margin = new System.Windows.Forms.Padding(6);
            this.txtQntSalas.Name = "txtQntSalas";
            this.txtQntSalas.Size = new System.Drawing.Size(530, 29);
            this.txtQntSalas.TabIndex = 8;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackColor = System.Drawing.Color.Yellow;
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.Location = new System.Drawing.Point(137, 587);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(6);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(861, 82);
            this.btnRegistrar.TabIndex = 9;
            this.btnRegistrar.Text = "Registrar os dados";
            this.btnRegistrar.UseVisualStyleBackColor = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(102, 64);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(977, 108);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "CADASTRO CINEMA";
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1179, 778);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.txtQntSalas);
            this.Controls.Add(this.txtCapacidade);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.lblQntSalas);
            this.Controls.Add(this.lblCapacidade);
            this.Controls.Add(this.lblEndereco);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.pnlCinema);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmQuestao02";
            this.Text = "Questao04";
            this.pnlCinema.ResumeLayout(false);
            this.pnlCinema.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCinema;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblCapacidade;
        private System.Windows.Forms.Label lblQntSalas;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCapacidade;
        private System.Windows.Forms.TextBox txtQntSalas;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Label lblTitulo;
    }
}
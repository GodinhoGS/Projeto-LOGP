﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App2B224JoaoPedroRodrigues
{
    public partial class Questao03 : Form
    {
        public Questao03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float salario = float.Parse(txtSalario.Text);
            double calcular;

            calcular = salario * 1.30;

            txtResultado.Text = calcular.ToString("C");
        }
    }
}

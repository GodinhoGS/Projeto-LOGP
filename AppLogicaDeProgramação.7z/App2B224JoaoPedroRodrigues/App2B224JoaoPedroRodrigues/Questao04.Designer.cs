﻿namespace App2B224JoaoPedroRodrigues
{
    partial class Questao04
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPi = new System.Windows.Forms.Label();
            this.lblRaio = new System.Windows.Forms.Label();
            this.txtPi = new System.Windows.Forms.TextBox();
            this.txtRaio = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPi
            // 
            this.lblPi.AutoSize = true;
            this.lblPi.Location = new System.Drawing.Point(33, 26);
            this.lblPi.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPi.Name = "lblPi";
            this.lblPi.Size = new System.Drawing.Size(164, 24);
            this.lblPi.TabIndex = 0;
            this.lblPi.Text = "Insire o valor do Pi";
            // 
            // lblRaio
            // 
            this.lblRaio.AutoSize = true;
            this.lblRaio.Location = new System.Drawing.Point(33, 76);
            this.lblRaio.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblRaio.Name = "lblRaio";
            this.lblRaio.Size = new System.Drawing.Size(179, 24);
            this.lblRaio.TabIndex = 1;
            this.lblRaio.Text = "Insire o valor do raio";
            // 
            // txtPi
            // 
            this.txtPi.Location = new System.Drawing.Point(224, 26);
            this.txtPi.Margin = new System.Windows.Forms.Padding(6);
            this.txtPi.Name = "txtPi";
            this.txtPi.Size = new System.Drawing.Size(180, 29);
            this.txtPi.TabIndex = 2;
            // 
            // txtRaio
            // 
            this.txtRaio.Location = new System.Drawing.Point(224, 76);
            this.txtRaio.Margin = new System.Windows.Forms.Padding(6);
            this.txtRaio.Name = "txtRaio";
            this.txtRaio.Size = new System.Drawing.Size(180, 29);
            this.txtRaio.TabIndex = 3;
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(169, 229);
            this.txtResultado.Margin = new System.Windows.Forms.Padding(6);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(180, 29);
            this.txtResultado.TabIndex = 4;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(28, 234);
            this.lblResultado.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(94, 24);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = "Resultado";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(96, 143);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(138, 42);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Questao04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 317);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtRaio);
            this.Controls.Add(this.txtPi);
            this.Controls.Add(this.lblRaio);
            this.Controls.Add(this.lblPi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Questao04";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPi;
        private System.Windows.Forms.Label lblRaio;
        private System.Windows.Forms.TextBox txtPi;
        private System.Windows.Forms.TextBox txtRaio;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnCalcular;
    }
}


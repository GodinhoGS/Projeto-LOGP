﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App2B224JoaoPedroRodrigues
{
    public partial class Questao04 : Form
    {
        public Questao04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float pi = float.Parse(txtPi.Text);
            float raio = float.Parse(txtRaio.Text);
            float area;

            area = pi * (raio * raio);

            txtResultado.Text = area.ToString();
        }
    }
}

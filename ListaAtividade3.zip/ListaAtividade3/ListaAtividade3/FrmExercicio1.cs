namespace ListaAtividade3
{
    public partial class FrmUm : Form
    {
        public FrmUm()
        {
            InitializeComponent();
        }


        private void btnMedia_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float media;

            media = (Num1 + Num2 + Num3) / 3;

            lblMedia.Text = "M�dia � igual a " + media;

        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float total, PorcNum1, PorcNum2, PorcNum3;

            total = Num1 + Num2 + Num3;
            PorcNum1 = Num1 / total;
            PorcNum2 = Num2 / total;
            PorcNum3 = Num3 / total;

            lblPorcentagem.Text = "Num1 � " + PorcNum1 + "% - " + " Num2 � " + PorcNum2 + "%" + " Num3 � "  + PorcNum3 + "%.";
        }

        private void btnSoma_Click_1(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = Num1 + Num3;

            lblSoma.Text = "Soma igual a " + soma;

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagemOFC
{
    public partial class form : Form
    {
        public form()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Formulário Aberto");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Inteiro");
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Decimal");
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão mostrar");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão limpar");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Texto");
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Booleano");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei um texto;");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Decimal");
        }
    }
}

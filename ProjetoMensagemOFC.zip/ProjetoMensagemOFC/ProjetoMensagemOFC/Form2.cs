﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagemOFC
{
    public partial class Formulário : Form
    {
        public Formulário()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Formulário Aberto");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Inteiro");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Decimal");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão mostrar");
        }

        private void txtBooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botão limpar");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Texto");
        }

        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar texto");
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Booleano");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrar Decimal");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alterei um texto;");
        }
    }
}
